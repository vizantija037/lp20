$(document).ready(function() {

  const $registerForm = $('#licenceForm')
  let validator = void(0)

  if ($registerForm.length) {
    validator = $registerForm.validate({
                                         rules: {
                                           insertCompany: { //po id-u
                                             required: true
                                           },
                                           insertName: { //po id-u
                                             required: true
                                           },
                                           insertMail: { //po id-u
                                             required: true
                                           },
                                           insertPib: { //po id-u
                                             required: true
                                           },
                                           insertMb: { //po id-u
                                             required: true
                                           },
                                           insertUID: { //po id-u
                                             required: true
                                           }
                                         },
                                         messages: {
                                           insertCompany: { //po id-u
                                             required: "Niste popunili ovo polje."
                                           },
                                           insertName: { //po id-u
                                             required: "Niste popunili ovo polje."
                                           },
                                           insertMail: { //po id-u
                                             required: "Niste popunili ovo polje."
                                           },
                                           insertPib: { //po id-u
                                             required: "Niste popunili ovo polje."
                                           },
                                           insertMb: { //po id-u
                                             required: "Niste popunili ovo polje."
                                           },
                                           insertUID: { //po id-u
                                             required: "Niste popunili ovo polje."
                                           }
                                         },
                                         submitHandler: function submitHandler(form) {
                                           event.preventDefault();
                                           $.ajax({
                                                    url: 'php_vendors/sendemail.php',
                                                    method: 'POST',
                                                    data: new FormData(form),
                                                    contentType: false,
                                                    processData: false,
                                                    success: function(data) {
                                                      let objResp = JSON.parse(data);
                                                      let str = objResp.type;
                                                      if (str === 'ERROR') {
                                                        str = objResp.data;
                                                        swal({
                                                               title: "ERROR",
                                                               text: str,
                                                               timer: 2500,
                                                               showCancelButton: false,
                                                               showConfirmButton: false,
                                                               type: "error"
                                                             });
                                                        return;
                                                      }

                                                      if (str === 'OK') {
                                                        str = objResp.data;
                                                        swal({
                                                               title: "SUCCESS",
                                                               text: str,
                                                               showCancelButton: false,
                                                               showConfirmButton: true,
                                                               type: "success",

                                                             }
                                                        );
                                                      }

                                                    }
                                                  })
                                         }
                                       })
  }

});
