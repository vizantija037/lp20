grecaptcha.ready(() => {
  grecaptcha.execute('6Lc4ZckdAAAAAHX6gN1kod1NatwEMd_ItAKmECqg') // site key from google
    .then((token) => {
      recaptchaResponse = document.getElementById('recaptchaResponse');
      recaptchaResponse.value = token;
    });
});
