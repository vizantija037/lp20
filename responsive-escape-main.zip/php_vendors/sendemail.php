<?php
include "class.user.php";

$user_class = new USER();

    if (isset($_REQUEST['recaptcha_response'])) {

        // Build POST request:
        $recaptcha_url = 'https://www.google.com/recaptcha/api/siteverify';
        $recaptcha_secret = '6Lc4ZckdAAAAAICFdwZZJ9S4MOkIouEymhDzRZtd'; // secret key sa googl-a
        $recaptcha_response = $_POST['recaptcha_response'];

        // Make and decode POST request:
        $recaptcha = file_get_contents($recaptcha_url . '?secret=' . $recaptcha_secret . '&response=' . $recaptcha_response);
        // echo $recaptcha;
        $recaptcha = json_decode($recaptcha);


        // Take action based on the score returned:
        if ($recaptcha->score >= 0.5) {
            if (isset($_REQUEST['insertCompany']) && isset($_REQUEST['insertName']) && isset($_REQUEST['insertMail']) && isset($_REQUEST['insertPib']) && isset($_REQUEST['insertMb']) && isset($_REQUEST['insertUID']) && isset($_REQUEST['insertMessage'])) {

                $email_to = "lpfr.hwt@gmail.com";
                $email_subject = "Zahtev za Licencu LP 20";


                $company  = $_POST['insertCompany'];
                $name     = $_POST['insertName'];
                $mail     = $_POST['insertMail'];
                $pib      = $_POST['insertPib'];
                $mb       = $_POST['insertMb'];
                $uid      = $_POST['insertUID'];
                $message  = $_POST['insertMessage'];
                //$time = $_POST['time'];


                function clean_string($string)
                {
                    $bad = array("content-type", "bcc:", "to:", "cc:", "href");
                    return str_replace($bad, "", $string);
                }

                $email_message = "Firma: " . clean_string($company) . "\n";
                $email_message .= "Kontakt osoba : " . clean_string($name) . "\n";
                $email_message .= "E-mail: " . clean_string($mail) . "\n";
                $email_message .= "PIB: " . clean_string($pib) . "\n";
                $email_message .= "MB: " . clean_string($mb) . "\n";
                $email_message .= "JID kartice: " . clean_string($uid) . "\n";
               //$email_message .= "Zahtevani vremenski period licence: " . clean_string($time) . "\n";
                $email_message .= "Poruka: " . clean_string($message) . "\n";

                $email_message = "<div>" . $email_message . "</div>";

                $headers = 'From: ' . $email . "\r\n" .
                    'Reply-To: ' . $email . "\r\n" .
                    'X-Mailer: PHP/' . phpversion();
                //if (@mail($email_to, $email_subject, $email_message, $headers)) {
                    $send = $user_class->send_mail($email, $email_message, $email_subject);
                if($send){
                    $user_class->returnJSON("OK","Poruka je poslata.");
                    return;
                } else {
                     $user_class->returnJSON("ERROR","Poruka nije poslata. Molimo pokušajte ponovo.");
                    return;
                };
            } else {
                //echo "nije sve setovanoi";
                $user_class->returnJSON("ERROR","Popunite sva obavezna polja.");
                return;
            }
        } else {
            // echo "error with recaptcha";
             $user_class->returnJSON("ERROR",
              "Problem sa recaptcha");
            return;
        }
    } else {
        //echo "error with recaptcha_response";
         $user_class->returnJSON("ERROR",
         "Problem sa recaptcha_response");
        return;
    }


?>
